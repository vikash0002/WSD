package iso;

public class Main {
  
  public static void main(String[] args) {
    // Tests.test1();
    // Tests.test2();
    // Tests.test3();
    // Tests.test4();
    // Tests.test5();
    // Tests.test6();
    // Tests.test7();
    // Tests.test8();
    // Tests.test9();
    Tests.test10();
    Tests.test11();
  }
  
}