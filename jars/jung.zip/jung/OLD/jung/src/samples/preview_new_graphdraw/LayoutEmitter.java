/*
 * Created on Mar 22, 2004
 */
package samples.preview_new_graphdraw;


/**
 * 
 * @author danyelf
 */
public interface LayoutEmitter {
    
    public EmittedLayout emit();

}
